module.exports = {
  OWNER_NAME: "Farooq",
  BOT_NAME: "Farooq_Bot",
  PREFIX: "!"
};
