module.exports = {
  name: "hello",
  run: () => {
    return "👋 Hello! I am Farooq_Bot";
  }
};
